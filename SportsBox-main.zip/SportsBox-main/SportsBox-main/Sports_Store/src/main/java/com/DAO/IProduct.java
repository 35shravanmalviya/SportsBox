package com.DAO;

import java.util.List;

import com.entity.Products;

public interface IProduct {

	public List<Products> getAllProducts();

	public Products getProductById(int id);

	public boolean updateEditProducts(Products p);

	public boolean deleteProducts(int id);

	boolean addProducts(Products p);
}
