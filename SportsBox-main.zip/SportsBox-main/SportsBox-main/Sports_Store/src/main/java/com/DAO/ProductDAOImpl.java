package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.entity.Products;

public class ProductDAOImpl implements IProduct {
	private Connection conn;
	
	public ProductDAOImpl() {
		super();
		this.conn=conn;
	}
	
	public ProductDAOImpl(Connection conn) {
		super();
		this.conn = conn;
	}
	
	@Override
	public boolean addProducts(Products p) {
		boolean f = false;
		try {
			String sql="insert into product(product_id,product_name,unit_price,quantity_in_stock,category_id,photo_name) values(?,?,?,?,?,?)";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, p.getProduct_id());
			ps.setString(2, p.getProduct_name());
			ps.setDouble(3, p.getUnit_price());
			ps.setInt(4, p.getQuantity_in_stock());
			ps.setInt(5, p.getCategory_id());
			ps.setString(6, p.getPhoto_name());
			
			int i=ps.executeUpdate();
			if(i == 1) {
				f=true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	@Override
	public List<Products> getAllProducts() {
		List<Products> list = new ArrayList<Products>();
		Products p=null;
		try {
			String sql = "select * from product";
			PreparedStatement ps=conn.prepareStatement(sql);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				p=new Products();
				p.setProduct_id(rs.getInt(1));
				p.setProduct_name(rs.getString(2));
				p.setUnit_price(rs.getDouble(3));
				p.setQuantity_in_stock(rs.getInt(4));
				p.setCategory_id(rs.getInt(5));
				p.setPhoto_name(rs.getString(6));
				list.add(p);
				
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Products getProductById(int id) {
		Products p = null;
		try {
			String sql = "select * from product where product_id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				p=new Products();
				p.setProduct_id(rs.getInt(1));
				p.setProduct_name(rs.getString(2));
				p.setUnit_price(rs.getDouble(3));
				p.setQuantity_in_stock(rs.getInt(4));
				p.setCategory_id(rs.getInt(5));
				p.setPhoto_name(rs.getString(6));
			}
		
		} catch (SQLException e) {
			
			e.printStackTrace();
		} 
		
		return p;
	}

	@Override
	public boolean updateEditProducts(Products p) {
		boolean f=false;
		try {
			String sql="update product set unit_price=? where product_id=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			//ps.setString(1, p.getProduct_name());
			ps.setDouble(1, p.getUnit_price());
			ps.setInt(2, p.getProduct_id());
			int i=ps.executeUpdate();
			if(i==1) {
				f=true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	@Override
	public boolean deleteProducts(int id) {
		boolean f=false;
		try {
			String sql="delete from product where product_id=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, id);
			int i=ps.executeUpdate();
			if(i==1) {
				f=true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	

}