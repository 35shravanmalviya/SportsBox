package com.user.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.CartDaoImpl;
import com.DAO.OrderDaoImpl;
import com.DB.DBConnect;
import com.entity.Cart;
import com.entity.Order;

/**
 * Servlet implementation class OrderServlet
 */
@WebServlet("/order")
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id"));
		
		String name = request.getParameter("username");
		String email = request.getParameter("email");
		String phno = request.getParameter("phno");
		String address = request.getParameter("address");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String pincode = request.getParameter("pincode");
		String landmark = request.getParameter("landmark");
		String paymentmode = request.getParameter("paymentmode");
		String orderDate = request.getParameter("date");
		String fullAddress = address + "," + landmark + "," + city + "," + state + "," +pincode;
		
		System.out.println(name+" "+email+" "+phno+" "+fullAddress);
		
		CartDaoImpl dao = new CartDaoImpl(DBConnect.getConn());
		List<Cart> list = dao.getProductByUser(id);
		
		
		OrderDaoImpl dao2 = new OrderDaoImpl(DBConnect.getConn());
		Order order = null;
		//int i = dao2.getOrderNo();
		
		ArrayList<Order> orderList = new ArrayList<Order>();
		
		HttpSession session = request.getSession();
		Random r = new Random();
		
		for(Cart c:list) {
			order = new Order();
			session.setAttribute("cartobj",order);
			order.setOrderId(r.nextInt(100));
			order.setCustomerName(name);
			order.setEmailId(email);
			order.setPhoneno(phno);
			order.setAddress(fullAddress);
			order.setOrderPrice(c.getCart_value());
			order.setOrderDate(orderDate);
			orderList.add(order);
			//i++; //for multiple products
		}
		
		if("noselect".equals(paymentmode)) {
			response.sendRedirect("order.jsp");
		}else {
			boolean f=dao2.saveOrder(orderList);
			if(f) {
				response.sendRedirect("invoice.jsp");
				System.out.println("Order placed successfully");
			}
			else {
				System.out.println("Cannot place an order");
			}
		}
		
		
		
	}

}