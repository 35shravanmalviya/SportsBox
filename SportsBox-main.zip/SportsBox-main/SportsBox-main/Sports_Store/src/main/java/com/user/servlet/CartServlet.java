package com.user.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.CartDaoImpl;
import com.DAO.ProductDAOImpl;
import com.DB.DBConnect;
import com.entity.Cart;
import com.entity.Products;

/**
 * Servlet implementation class CartServlet
 */
@WebServlet("/cart")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartServlet() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			int productId = Integer.parseInt(request.getParameter("pid"));
			int userId = Integer.parseInt(request.getParameter("uid"));
			
			CartDaoImpl dao1 = new CartDaoImpl(DBConnect.getConn());
			Cart c1 = dao1.getOneProductItemFromCart(userId, productId);
			if(c1!=null&&c1.getProduct_id()==productId) {
				boolean f = dao1.IncrementQuantity(c1.getCart_id(), productId);
				if(f)
				{
					response.sendRedirect("cart.jsp");
				}
			}
			else {
			ProductDAOImpl dao = new ProductDAOImpl(DBConnect.getConn());
			Products p = dao.getProductById(productId);
			
			HttpSession session = request.getSession();
			
			
			Cart c = new Cart();
			session.setAttribute("cartobj",c);
			c.setCart_id(c.getCart_id());
			c.setCustomer_id(userId);
			c.setProduct_name(p.getProduct_name());
			c.setCart_value(p.getUnit_price());
			c.setPhoto_name(p.getPhoto_name());
			c.setProduct_id(productId);
			//c.setPhoto_name(p.getPhoto_name());
			c.setQuantity(1);
			
			CartDaoImpl dao2 = new CartDaoImpl(DBConnect.getConn());
			
			boolean f = dao2.addToCart(c);
			
			
			
		if(f) {

			session.setAttribute("cartobj",c);
			//	RequestDispatcher rd = request.getRequestDispatcher("all_component/home.jsp");
				//rd.forward(request, response);
			response.sendRedirect("cart.jsp");
				System.out.println("Added to cart");
			}else {
//				session.setAttribute("failed", "Something went wrong");
//				RequestDispatcher rd = request.getRequestDispatcher("all_component/home.jsp");
//				rd.forward(request, response);
////				response.sendRedirect("all_component/home.jsp");
				System.out.println("Not added to cart");
			}
			//}	
		}} catch (NumberFormatException e) {
			e.printStackTrace();
		}
	}

}