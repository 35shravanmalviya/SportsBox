package com.user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.CartDaoImpl;
import com.DB.DBConnect;
import com.entity.Cart;

/**
 * Servlet implementation class IncrementQuantityServlet
 */
@WebServlet("/icart")
public class IncrementQuantityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IncrementQuantityServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int cartId = Integer.parseInt(request.getParameter("cartId"));
		int productId = Integer.parseInt(request.getParameter("productId"));
		
		CartDaoImpl dao = new CartDaoImpl(DBConnect.getConn());
		HttpSession session = request.getSession();
		Cart c=(Cart) session.getAttribute("cartobj");
	
		try {
			boolean isUpdated = dao.IncrementQuantity(cartId, productId);
			if(isUpdated) {
				System.out.println("updated");
			
				response.sendRedirect("cart.jsp");
			}else {
				System.out.println("cannot update");
				response.sendRedirect("cart.jsp");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}