package com.user.servlet;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.UserDAOImpl;
import com.DB.DBConnect;
import com.entity.User;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			UserDAOImpl dao=new UserDAOImpl(DBConnect.getConn());
			
			HttpSession session=req.getSession();
			
			String email=req.getParameter("email").toLowerCase();
			String password=req.getParameter("password").trim();
			
			if("admin123@gmail.com".equals(email) && "Nsaap@123".equals(password)) {
				User us=new User();
				session.setAttribute("userobj", us);
				resp.sendRedirect("admin/home.jsp");
			}else {
				
				User us=dao.login(email, password);
				if(us!=null) {
					session.setAttribute("userobj", us);
					resp.sendRedirect("index2.jsp");
//					RequestDispatcher rd = req.getRequestDispatcher("index.jsp");  
//					rd.forward(req, resp);  
			System.out.println("Welcome");
				}else {
					resp.sendRedirect("login.jsp");
//					RequestDispatcher rd = req.getRequestDispatcher("login.jsp");  
//					rd.forward(req, resp);  
					session.setAttribute("failedMsg", "Email & Password Invalid");
					
				}
				
				resp.sendRedirect("index2.jsp");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	
}