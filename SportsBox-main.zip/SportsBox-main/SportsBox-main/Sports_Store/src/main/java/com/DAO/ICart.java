package com.DAO;

import java.util.List;

import com.entity.Cart;

public interface ICart {
	public boolean addToCart(Cart c);
	public List<Cart> getProductByUser(int userId);
	public boolean IncrementQuantity(int cartId,int productId);
	public boolean DecrementQuantity(int CartId,int productId);
	public boolean RemoveCartItem(int CartId,int UserId);
	public Cart getOneProductItemFromCart(int customerId,int ProductId);
	public long getGrandTotal(int customerId);
	public long getTotalQuantity(int customerId);
}