package com.DAO;
import com.entity.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Order;
import com.entity.Products;

public class OrderDaoImpl implements IOrder {
	private Connection conn;
	
	public OrderDaoImpl(Connection conn) {
		super();
		this.conn = conn;
	}

//	@Override
//	public int getOrderNo() {
//		int i=1;
//		try {
//			String sql = "select * from orders";
//			PreparedStatement ps = conn.prepareStatement(sql);
//			ResultSet rs = ps.executeQuery();
//			while(rs.next()) {
//				i++;
//			}
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//		return i;
//	}
	@Override
	public List<Order> getOrderDetails() {
		List<Order> list = new ArrayList<Order>();
		Order o=null;
		try {
			String sql = "select * from orders3";
			PreparedStatement ps=conn.prepareStatement(sql);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				o=new Order();
				o.setOrderId(rs.getInt(1));
				o.setOrderDate(rs.getString(2));
				o.setOrderPrice(rs.getDouble(3));
				o.setAddress(rs.getString(4));
				o.setPhoneno(rs.getString(5));
				o.setCustomerName(rs.getString(6));
				o.setEmailId(rs.getString(7));
				list.add(o);
				
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	@Override
	public boolean saveOrder(List<Order> list) {
		boolean f=false;
		try {
			
			String sql = "select order_id_seq.nextval from customers";
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
		
			if(rs.next()) {
			    int order_id_seq = rs.getInt(1);
			    System.out.println(order_id_seq);
			String sql1 = "insert into orders3(order_id,order_date,order_price,address,phoneno,customer_name,emailid) VALUES (?,?,?,?,?,?,?)";
			
			conn.setAutoCommit(f);
			PreparedStatement ps = conn.prepareStatement(sql1);
			//using for each loop in case if customer has more than one product
			for(Order o:list) {
				ps.setInt(1,order_id_seq);
				ps.setString(2, o.getOrderDate());
				ps.setDouble(3, o.getOrderPrice());
				ps.setString(4, o.getAddress());
				ps.setString(5,o.getPhoneno());
				ps.setString(6,o.getCustomerName());
				ps.setString(7	,o.getEmailId());
				//list.add(o);
				ps.addBatch();
			}
			int [] count = ps.executeBatch();
			conn.commit();
			f=true;
			conn.setAutoCommit(true);
			
		}}catch(Exception e) {
			e.printStackTrace();
		}
		return f;
	}

}