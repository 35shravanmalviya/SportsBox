package com.DAO;

import java.util.List;

import com.entity.Order;
import com.entity.Products;

public interface IOrder {
	//public int getOrderNo();
	public boolean saveOrder(List<Order> o);
	public List<Order> getOrderDetails();
}