package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.entity.Cart;
import com.entity.Products;

public class CartDaoImpl implements ICart {
	
	private Connection conn;
	
	public CartDaoImpl(Connection conn) {
		super();
		this.conn = conn;
	}

	/**
	 *
	 */
	//adding to cart functionality
	@Override
	public boolean addToCart(Cart c) {
		
		boolean f = false;
		try {
			String sql = "select cart_id_seq.nextval from customers";
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
		
			if(rs.next()) {
			    int cart_id_seq = rs.getInt(1);
		
			
			String sql1 = "insert into cart(product_name,product_quantity,cart_value,cart_id,customer_id,photo_name,product_id) VALUES (?,?,?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(sql1);
			ps.setString(1, c.getProduct_name());
			ps.setInt(2, c.getQuantity());
			ps.setDouble(3, c.getCart_value());
			ps.setInt(4, cart_id_seq);
			ps.setInt(5, c.getCustomer_id());
			ps.setString(6, c.getPhoto_name());
			ps.setInt(7, c.getProduct_id());
			System.out.println("data inserted successfully");
			int i = ps.executeUpdate();
			if(i==1) {
				f=true;
			}
		}}catch(Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	//for displaying cart items
	@Override
	public List<Cart> getProductByUser(int userId) {
		List<Cart> list = new ArrayList<Cart>();
		Cart c=null;
		double cart_value=0;
		try {
			String sql="select * from cart where customer_id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				c=new Cart();
				c.setProduct_name(rs.getString("product_name"));
				c.setQuantity(rs.getInt("product_quantity"));
				c.setCart_id(rs.getInt("cart_id"));
				c.setCart_id(rs.getInt("cart_id"));
				c.setPhoto_name(rs.getString("photo_name"));
				//cart_value=cart_value+rs.getDouble("cart_value");
				c.setCart_value(rs.getInt("cart_value"));
				c.setProduct_id(rs.getInt("product_id"));
				c.setCustomer_id(rs.getInt("customer_id"));
				//System.out.println(cart_value);
				list.add(c);
				
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	//getting single product from cart
	@Override
	public Cart getOneProductItemFromCart(int customerId, int ProductId) {
		Cart cart = null;
		try {
			String sqlQuery = "select cart_id,product_quantity,cart_value,product_id,product_name,customer_id from cart where customer_id=? and product_id=?";
			
			PreparedStatement ps = conn.prepareStatement(sqlQuery);
			ps.setInt(1, customerId);
			ps.setInt(2, ProductId);
			System.out.println(ps.toString());
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				cart = new Cart();
				
				cart.setCart_id(rs.getInt("cart_id"));
				cart.setQuantity(rs.getInt("product_quantity"));
				cart.setCart_value(rs.getInt("cart_value"));
				cart.setProduct_id(rs.getInt("product_id"));
				cart.setProduct_name(rs.getString("product_name"));
				cart.setCustomer_id(rs.getInt("customer_id"));
				
				
				
				return cart;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public boolean IncrementQuantity(int cartId,int productId) {
		String UpdateQuery="update cart set product_quantity=(select product_quantity+1 from cart where cart_id=?),cart_value=(select unit_price*(select product_quantity+1 from cart where cart_id=?) from product where product_id=?) where cart_id=?";
		try {
			PreparedStatement ps = conn.prepareStatement(UpdateQuery);
			ps.setInt(1, cartId);
			ps.setInt(2, cartId);
			ps.setInt(3, productId);
			ps.setInt(4, cartId);
			int isUpdated = ps.executeUpdate();
			if(isUpdated>0) {
				return true;
			}
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public boolean DecrementQuantity(int cartId,int productId) {
		String UpdateQuery="update cart set product_quantity=(select product_quantity-1 from cart where cart_id=?),cart_value=(select unit_price*(select product_quantity-1 from cart where cart_id=?) from product where product_id=?) where cart_id=?";
		try {
			PreparedStatement ps = conn.prepareStatement(UpdateQuery);
			ps.setInt(1, cartId);
			ps.setInt(2, cartId);
			ps.setInt(3, productId);
			ps.setInt(4, cartId);
			int isUpdated = ps.executeUpdate();
			if(isUpdated>0) {
				ps.close();
				conn.close();
				return true;
			}
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean RemoveCartItem(int CartId, int UserId) {
		String RemoveQuery = "delete from cart where cart_id=? and customer_id=?";
		try {
			PreparedStatement ps = conn.prepareStatement(RemoveQuery);
			ps.setInt(1, CartId);
			ps.setInt(2, UserId);
			int isDeleted = ps.executeUpdate();
			if(isDeleted>0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public long getGrandTotal(int customerId) {
		String priceQuery = "select sum(cart_value) from cart where customer_id=? group by customer_id";
		try (PreparedStatement ps = conn.prepareStatement(priceQuery)) {
	        ps.setInt(1, customerId);
	        try (ResultSet rs = ps.executeQuery()) {
	            if (rs.next()) {
	                int totalPrice = rs.getInt(1);
	                return (long) totalPrice; // cast to long to match method signature
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return 0;
	}


//	@Override
//	public long getTotalQuantity(int customerId) {
//		String quantityQuery = "select sum(product_quantity) from cart group by customer_id=?";
//		try {
//			PreparedStatement ps1 = conn.prepareStatement(quantityQuery);
//			ps1.setInt(1,customerId);
//			int totalQuantity = ps1.executeUpdate();
//			return totalQuantity;
//			
//		} catch (SQLException e) {
//			
//			e.printStackTrace();
//		}
//		return 0;
//		
//	}
	@Override
	public long getTotalQuantity(int customerId) {
	    String quantityQuery = "SELECT SUM(product_quantity) FROM cart WHERE customer_id=? group by customer_id";
	    try (PreparedStatement ps = conn.prepareStatement(quantityQuery)) {
	        ps.setInt(1, customerId);
	        try (ResultSet rs = ps.executeQuery()) {
	            if (rs.next()) {
	                int totalQuantity = rs.getInt(1);
	                return (long) totalQuantity; // cast to long to match method signature
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return 0;
	}

	

	

	
}